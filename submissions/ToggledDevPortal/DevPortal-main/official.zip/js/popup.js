// document.getElementById('openNewTabButton').addEventListener('click', function() {
    chrome.tabs.create({ url: 'chrome://newtab' });
//   });
  